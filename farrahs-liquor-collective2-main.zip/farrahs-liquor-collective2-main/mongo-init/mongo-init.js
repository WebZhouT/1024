db.createUser({
    user: 'Frank',
    pwd: 'Wuzefan990805',
    roles: [
        {
            role: 'readWrite',
            db: 'fourBlockDB',
        },
    ],
});