cd ./farrahsliquorcollective2-frontend
git checkout main
git pull

cd ../fourBlock
git checkout main
git pull

cd ..
git checkout master
git pull

docker-compose stop
docker-compose up -d --build
docker system prune -a