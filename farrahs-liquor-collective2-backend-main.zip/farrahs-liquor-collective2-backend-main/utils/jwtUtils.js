const jwt = require("jsonwebtoken");
const secretKey = "4Block"; // Make sure this is kept secret!

function issueToken(adminId) {
  const payload = {
    adminId: adminId,
    issuedAt: Date.now(),
  };
  return jwt.sign(payload, secretKey, { expiresIn: "1h" });
}

function authenticateJWT(req, res, next) {
  // Get token from the header
  const bearerHeader = req.header("Authorization");

  if (!bearerHeader || !bearerHeader.startsWith("Bearer ")) {
    return res
      .status(401)
      .json({ message: "No token provided, authorization denied." });
  }

  const token = bearerHeader.split(" ")[1];

  // Check if token is not present
  if (!token) {
    return res
      .status(401)
      .json({ message: "No token provided, authorization denied." });
  }

  try {
    jwt.verify(token, secretKey, (err, decoded) => {
      if (err) {
        return res.status(403).json({ error: "Failed to authenticate token." });
      }

      // Attach the decoded payload to the request object
      req.user = decoded;
      next();
    });
  } catch (err) {
    res.status(401).json({ message: "Token is invalid." });
  }
}

module.exports = {
  issueToken,
  authenticateJWT,
};
