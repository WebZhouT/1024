const block = require('../models/Block');
const blockChain = require('../models/BlockChain');
const coupon = require('../models/Coupon');
const CouponCounter = require('../models/CouponCounter');

async function appendBlockToBlockchain(couponId, userId) {
    try {
        // 1. Find the blockchain & the coupon for the user
        const oldChain = await blockChain.findOne({ userId: userId });
        const couponOnChain = await coupon.findById(couponId);

        // Get or create the CouponCounter
        let counterDoc = await CouponCounter.findOne();
        if (!counterDoc) {
            counterDoc = new CouponCounter();
            await counterDoc.save();
        }

        // Increase the counter
        counterDoc.counter += 1;
        await counterDoc.save();

        // Generate the couponId using the updated counter
        const couponIdUnique = `FLC-${String(counterDoc.counter).padStart(5, '0')}`;

        // 2. Create a new block
        const blockNew = new block({
            index: oldChain.chain.length,
            timestamp: new Date().toISOString(),
            previousHash: oldChain.chain[oldChain.chain.length - 1].hash,
            data: {
                couponId: couponIdUnique,
                expireDate: couponOnChain.expireDate,
                description: couponOnChain.description,
                scheduleTime: couponOnChain.scheduleTime,
                isDefault: couponOnChain.isDefault,
                isRedeemed: couponOnChain.isRedeemed,
                isPushed: couponOnChain.isPushed,
            }
        });

        await blockNew.save();

        // Now that the block has an _id, update the block's data to include it
        blockNew.data.block_id = blockNew._id;

        // Save the block again with the updated data
        await blockNew.save();

        // 3. Append the block to the blockchain
        oldChain.chain.push(blockNew);

        // 4. Save the blockchain
        await oldChain.save();
        console.log(`Block for coupon ${couponId} added to blockchain for user ${userId}`);
    } catch (err) {
        console.error(`Error appending block to blockchain for user ${userId}:`, err);
    }
}

module.exports = { appendBlockToBlockchain };