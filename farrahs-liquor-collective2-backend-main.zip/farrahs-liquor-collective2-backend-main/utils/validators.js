const { body } = require('express-validator');

const userValidators = [
    body('userHash')
        .trim()
        .not()
        .isEmpty()
        .withMessage('User hash is required.'),
    body('endpoint')
        .optional()
        .isURL()
        .withMessage('Endpoint must be a valid URL.'),
    body('expirationTime')
        .optional()
        .custom(value => typeof value === 'number' || value === null)
        .withMessage('Expiration time must be a number or null.'),
    body('keys')
        .optional()
        .isObject()
        .withMessage('Keys must be an object.')
];

const getInfoValidators = [
    body('userHash')
        .trim()
        .not()
        .isEmpty()
        .withMessage('User hash is required.'),
    body('endpoint')
        .optional()
        .isURL()
        .withMessage('Endpoint must be a valid URL.'),
    body('keys')
        .optional()
        .isObject()
        .withMessage('Keys must be an object.')
];

module.exports = { userValidators, getInfoValidators };
