require("dotenv").config({ path: `.env.${process.env.NODE_ENV}` });
const bodyParser = require("body-parser");
const express = require("express");
const cors = require("cors");
const https = require("https");
const http = require("http");
const fs = require("fs");
const app = express();
app.use(cors());
app.use(express.json()); // to parse JSON bodies

require("./db"); // require the db.js

// Require your routes
const businessOwnerRoutes = require("./routes/businessOwnerRoutes");
const userRoutes = require("./routes/userRoutes");
const couponRoutes = require("./routes/couponRoutes");
const notificationRoutes = require("./services/couponNotificationService");
const blockChainRoutes = require("./routes/blockChainRoutes");
const statsRoutes = require("./routes/statsRoutes");
const feedbackRoutes = require("./routes/feedBackRoutes");
const adminRoutes = require('./routes/adminRoutes');

// Use your routes
app.use("/", businessOwnerRoutes);
app.use("/", userRoutes);
app.use("/", couponRoutes);
app.use("/", notificationRoutes);
app.use("/", blockChainRoutes);
app.use("/", statsRoutes);
app.use("/", feedbackRoutes);
app.use('/admin', adminRoutes);

// ... other imports and app setup ...

let server;
let privateKey;
let certificate;

if (process.env.NODE_ENV === "development") {
  // privateKey = fs.readFileSync('./localhost-key.pem', 'utf8'); // Updated path
  // certificate = fs.readFileSync('./localhost.pem', 'utf8'); // Updated path
  server = http.createServer(app);
} else {

  const privateKeyPath = "/etc/letsencrypt/live/vps3.4data.com.au-0003/privkey.pem";
  const certificatePath = "/etc/letsencrypt/live/vps3.4data.com.au-0003/fullchain.pem";

  if (fs.existsSync(privateKeyPath) && fs.existsSync(certificatePath)) {
    privateKey = fs.readFileSync(privateKeyPath, "utf8");
    certificate = fs.readFileSync(certificatePath, "utf8");

    const credentials = {
      key: privateKey,
      cert: certificate,
    };

    server = https.createServer(credentials, app);
  } else {
    console.warn("SSL certificates not found. Falling back to HTTP.");
    console.log("DB_URL:", process.env.DB_URL);
    server = http.createServer(app);
  }
}

const port = process.env.PORT || 3008;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});
