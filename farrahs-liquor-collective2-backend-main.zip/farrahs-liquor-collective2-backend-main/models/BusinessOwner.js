const mongoose = require('mongoose');

// Define the business owner schema
const businessOwnerSchema = new mongoose.Schema({
    companyName: { type: String, required: true }
});

module.exports = mongoose.model('BusinessOwner', businessOwnerSchema);