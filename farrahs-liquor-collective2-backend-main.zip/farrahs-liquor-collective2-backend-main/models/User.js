const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
    userHash: {
        type: String,
        required: true
    },
    subscriptionStatus: { 
        type: Boolean, 
        default: false 
    },
    subInfo: [{
        type: mongoose.Schema.Types.ObjectId,
        ref: "Subscription"
    }],
    activityLog: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "LogChain"
    },
    defaultCoupon: { 
        type: mongoose.Schema.Types.ObjectId, 
        ref: 'Coupon' 
    },
    invitationCode: {
        type: String,
        unique: true  // Ensure invitation codes are unique
    },
    blockChain: {
        type: mongoose.Schema.Types.ObjectId,
        ref: "BlockChain"
    },
    referredBy: String
});

module.exports = mongoose.model('User', userSchema);