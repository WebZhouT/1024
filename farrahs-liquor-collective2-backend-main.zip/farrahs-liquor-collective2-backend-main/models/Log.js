const mongoose = require('mongoose');
const crypto = require('crypto-js');

const logSchema = new mongoose.Schema({
    index: Number,
    timestamp: Date,
    data: { type: mongoose.Schema.Types.ObjectId },
    previousHash: String,
    hash: String
});

logSchema.pre('save', async function (next) {
    this.hash = await this.calculateHash();
    next();
});

logSchema.methods.calculateHash = function () {
    return crypto.SHA256(this.index + this.previousHash + this.timestamp + JSON.stringify(this.data)).toString();
}

module.exports = mongoose.model('Log', logSchema);