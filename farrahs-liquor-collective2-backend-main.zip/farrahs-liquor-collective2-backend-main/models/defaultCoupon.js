const mongoose = require('mongoose');
require("dotenv").config({ path: `.env.${process.env.NODE_ENV}` });

// Define the default coupon schema
const defaultCouponSchema = new mongoose.Schema({
    expireDate: { type: Date, required: true },
    description: { type: String, required: true},
});

module.exports = mongoose.model('defaultCoupon', defaultCouponSchema);