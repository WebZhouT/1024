// couponCounter.js

const mongoose = require('mongoose');

const couponCounterSchema = new mongoose.Schema({
    counter: { type: Number, default: 0 }
});

module.exports = mongoose.model('CouponCounter', couponCounterSchema);