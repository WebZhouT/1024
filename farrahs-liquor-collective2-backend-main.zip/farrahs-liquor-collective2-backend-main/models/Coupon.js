const mongoose = require('mongoose');

// Define the coupon schema
const couponSchema = new mongoose.Schema({
    expireDate: { type: Date, required: true },
    description: { type: String, required: true },
    scheduleTime: { type: Date },
    isPushed: { type: Boolean, default: false },
    isDefault: { type: Boolean, default: false },
    isRedeemed: { type: Boolean, default: false },
});

module.exports = mongoose.model('Coupon', couponSchema);
