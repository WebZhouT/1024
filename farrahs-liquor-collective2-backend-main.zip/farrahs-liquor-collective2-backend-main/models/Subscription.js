const mongoose = require('mongoose');

const subscriptionSchema = new mongoose.Schema({
    userId: { type: String, required: true },
    endpoint: String,
    expirationTime: Date, // if there's an expiration time
    keys: {
        p256dh: String,
        auth: String
    }
});

module.exports = mongoose.model('Subscription', subscriptionSchema);
