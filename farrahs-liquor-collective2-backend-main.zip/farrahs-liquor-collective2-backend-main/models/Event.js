const mongoose = require('mongoose');

// Define the coupon schema
const eventSchema = new mongoose.Schema({
    date: { type: Date, required: true },
    description: { type: String, required: true },
    topic: { type: String, required: false }
});

module.exports = mongoose.model('Event', eventSchema);