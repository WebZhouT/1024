const mongoose = require('mongoose');
const crypto = require('crypto-js');

const blockSchema = new mongoose.Schema({
    index: Number,
    timestamp: String,
    previousHash: String,
    hash: String,
    data: mongoose.Schema.Types.Mixed
});

blockSchema.pre('save', async function (next) {
    this.hash = await this.calculateHash();
    next();
});

blockSchema.methods.calculateHash = function () {
    return crypto.SHA256(this.index + this.previousHash + this.timestamp + JSON.stringify(this.data)).toString();
}

module.exports = mongoose.model('Block', blockSchema);