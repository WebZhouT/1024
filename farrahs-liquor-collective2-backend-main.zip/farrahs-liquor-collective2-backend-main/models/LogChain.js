// UserLog is a type of BlockChain that keeps track of the user's subscription status changes
const mongoose = require('mongoose');
const crypto = require('crypto-js');
const logSchema = require('./Log').schema;

const logChainSchema = new mongoose.Schema({
    userHash: {
        type: String,
        required: true
    },
    chain: [logSchema]
});

logChainSchema.methods.calculateHash = function (block) {
    return crypto.SHA256(block.index + block.previousHash + block.timestamp + JSON.stringify(block.data)).toString();
}

logChainSchema.methods.isChainValid = function () {
    for (let i = 1; i < this.chain.length; i++) {
        const currentBlock = this.chain[i];
        const previousBlock = this.chain[i - 1];
        const currentBlockCalculatedHash = currentBlock.calculateHash();

        // For debugging
        // console.log('Current block hash:', currentBlock.hash);
        // console.log('Calculated hash:', currentBlockCalculatedHash);

        // Calculate the hash of the block to ensure it hasn't been altered
        if (currentBlock.hash !== currentBlockCalculatedHash) {
            return false;
        }

        // Compare the current block's 'previousHash' to the hash of the previous block
        if (currentBlock.previousHash !== previousBlock.hash) {
            return false;
        }
    }

    return true;
}

module.exports = mongoose.model('LogChain', logChainSchema);