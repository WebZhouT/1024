// this script is a one-time script to create an admin user in the database
const Admin = require('./models/Admin');
const mongoose = require('mongoose');
const connectionString = 'mongodb://Frank:Wuzefan990805@localhost:27017/?authMechanism=SCRAM-SHA-256';

mongoose.connect(connectionString, { useNewUrlParser: true, useUnifiedTopology: true })
    .then(() => {
        console.log('Connected to MongoDB');
        // Rest of your seed script here
    })
    .catch(err => {
        console.error('Failed to connect to MongoDB:', err);
    });

async function createAdmin() {
    const admin = new Admin({
        username: 'Frank',
        password: '4data123'  // Use plain password here
    });
    await admin.save();
    console.log('Admin user created!');
}

createAdmin();