const express = require('express');
const router = express.Router();
const { getUserInfoAdmin, login } = require('../controllers/adminController');
const { authenticateJWT } = require('../utils/jwtUtils');

router.post('/admin/user_info', getUserInfoAdmin);
router.post('/login', login);

module.exports = router;
