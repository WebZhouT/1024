const express = require('express');
const router = express.Router();
const {
    createBusinessOwner,
    getBusinessOwner,
    updateBusinessOwner,
    deleteBusinessOwner
} = require('../controllers/businessOwnerController');

router.post('/businessOwner', createBusinessOwner);
router.get('/businessOwner/:id', getBusinessOwner);
router.put('/businessOwner/:id', updateBusinessOwner);
router.delete('/businessOwner/:id', deleteBusinessOwner);

module.exports = router;