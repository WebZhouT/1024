const express = require('express');
const router = express.Router();
const {
    createBlockchain,
    getBlockchain,
    updateBlockchain,
    deleteBlockchain
} = require('../controllers/blockChainController');

router.post('/blockchain', createBlockchain);
router.get('/blockchain/:userId', getBlockchain);
router.put('/blockChain/:id', updateBlockchain);
router.delete('/blockChain/:id', deleteBlockchain);

module.exports = router;
