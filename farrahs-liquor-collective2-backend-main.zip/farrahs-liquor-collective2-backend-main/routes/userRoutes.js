const express = require("express");
const {
  withBlockchainSubscribe,
  getDefaultCoupon,
  getCoupons,
  getUserById,
  getUserInfo,
  getUserByHash,
  subscribeUser,
  unsubscribeUser,
  deleteUser,
  updateSubscription,
} = require("../controllers/userController");
const { userValidators, getInfoValidators } = require("../utils/validators");
const router = express.Router();

router.post("/user/withBlockchainSubscribe", userValidators, withBlockchainSubscribe);
router.post("/user/defaultCoupon", getDefaultCoupon);
router.post("/user/coupons", getCoupons);
router.get("/user/:id", getUserById);
router.post("/user/getInfo", getInfoValidators, getUserInfo);
router.get("/user/hash/:hash", getUserByHash);
router.put("/user/:id/subscribe", subscribeUser);
router.put("/user/unsubscribe", unsubscribeUser);
router.delete("/user/:id", deleteUser);
router.post('/user/pushsubscriptionchange', updateSubscription);

module.exports = router;