const express = require('express');
const router = express.Router();
const { getStats } = require('../controllers/statsController');

router.get('/api/v1/stats', getStats);

module.exports = router;