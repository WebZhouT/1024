const express = require('express');
const router = express.Router();
const { authenticateJWT } = require('../utils/jwtUtils');
const {
    createDefaultCoupon,
    updateDefaultCoupon,
    getDefaultCoupon,
    createCoupon,
    getCoupon,
    getNonDefaultCoupons,
    updateCoupon,
    deleteCoupon,
    redeemCoupon
} = require('../controllers/couponController');

router.get('/defaultCoupon', getDefaultCoupon);
router.get('/coupon/:couponId', getCoupon);
router.get('/coupons/nonDefault', getNonDefaultCoupons);

router.post('/defaultCoupon', authenticateJWT, createDefaultCoupon);
router.put('/defaultCoupon/', authenticateJWT, updateDefaultCoupon);
router.post('/coupon', authenticateJWT, createCoupon);
router.put('/coupon/:id', authenticateJWT, updateCoupon);
router.delete('/coupon/:id', authenticateJWT, deleteCoupon);
router.put('/coupon/redeem/:id', authenticateJWT, redeemCoupon);

module.exports = router;
