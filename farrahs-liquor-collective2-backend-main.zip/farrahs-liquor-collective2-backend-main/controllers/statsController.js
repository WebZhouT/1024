const User = require('../models/User');
const Coupon = require('../models/Coupon');
const BlockChain = require('../models/BlockChain');
const LogChain = require('../models/LogChain');
const Subscription = require('../models/Subscription');
const Event = require('../models/Event');

exports.getStats = async (req, res) => {
    try {
        // Get the total number of users
        const totalUsers = await User.countDocuments();

        // Get the total number of subscribed users
        const totalSubscribedUsers = await User.countDocuments({ subscriptionStatus: true });

        // Get the total number of unsubscribed users
        const totalUnsubscribedUsers = await User.countDocuments({ subscriptionStatus: false });

        // Get the total number of coupons
        const totalCoupons = await Coupon.countDocuments();

        // Get the total number of redeemed coupons
        const totalRedeemedCoupons = await Coupon.countDocuments({ isRedeemed: true });

        // Get the total number of blockchains
        const totalBlockChains = await BlockChain.countDocuments();

        // Get the total number of log chains
        const totalLogChains = await LogChain.countDocuments();

        // Get the total number of subscriptions
        const totalSubscriptions = await Subscription.countDocuments();

        // Get the total number of events
        const totalEvents = await Event.countDocuments();

        // Return the statistics
        res.json({
            totalUsers,
            totalSubscribedUsers,
            totalUnsubscribedUsers,
            totalCoupons,
            totalRedeemedCoupons,
            totalBlockChains,
            totalLogChains,
            totalSubscriptions,
            totalEvents
        });
    } catch (err) {
        // Send an error response if something went wrong
        res.status(500).json({ error: err.message });
    }
};