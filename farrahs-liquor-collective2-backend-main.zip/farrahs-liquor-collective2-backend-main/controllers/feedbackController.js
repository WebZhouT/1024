const nodemailer = require("nodemailer");

// Nodemailer transporter
const transporter = nodemailer.createTransport({
  host: process.env.EMAIL_HOST,
  port: process.env.EMAIL_PORT,
  secure: false, // true for 465, false for other ports
  auth: {
    user: process.env.EMAIL_USERNAME,
    pass: process.env.EMAIL_PASSWORD,
  },
});

exports.sendFeedback = async (req, res) => {
  try {
    const { phone, email, name, feedback } = req.body;

    // Construct the HTML for the email
    let htmlContent = `
            <h1>New Feedback Received from Farrahsliquorcollective</h1>
            <p><strong>Name:</strong> ${name}</p>
            <p><strong>Email:</strong> ${email}</p>
            <p><strong>Phone:</strong> ${phone}</p>
            <p><strong>Feedback:</strong></p>
            <p>${feedback}</p>
        `;

    let mailOptions = {
      from: "Farrahs.LiquorCollective@farrahsliquorcollective2.com",
      to: "support@4data.com.au",
      subject: "New Feedback Received from Farrahsliquorcollective",
      html: htmlContent, // Use the 'html' property instead of 'text'
    };

    let info = await transporter.sendMail(mailOptions);
    res.json({ message: "Feedback sent successfully!" });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Error sending feedback." });
  }
};
