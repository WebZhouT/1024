const block = require('../models/Block');
const blockChain = require('../models/BlockChain');

exports.createBlockchain = async (req, res) => {
    const userId = req.body.userId;
    const businessOwner = req.body.businessOwner;

    const genesisBlock = new block({
        index: 0,
        timestamp: new Date().toISOString(),
        previousHash: "0",
        data: null  // No data for the genesis block
    });

    genesisBlock.hash = genesisBlock.calculateHash();

    try {
        await genesisBlock.save();

        const blockchainNew = new blockChain({
            userId: userId,
            businessOwner: businessOwner,
            chain: [genesisBlock]
        });

        await blockchainNew.save();

        res.json(blockchainNew);
    } catch (err) {
        console.error(err);
        res.status(500).json({ error: 'Error creating blockchain' });
    }
};

exports.getBlockchain = (req, res) => {
    blockChain.findOne({ userId: req.params.userId })
        .then(blockchain => {
            res.json(blockchain);
        })
        .catch(err => {
            res.status(500).json({ error: err.toString() });
        });
};

exports.updateBlockchain = async (req, res) => {
    // logic here to update a blockchain by id
};

exports.deleteBlockchain = async (req, res) => {
    // logic here to delete a blockchain by id
};