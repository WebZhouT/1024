const businessOwner = require('../models/BusinessOwner');

exports.createBusinessOwner = async (req, res) => {
    const businessOwnerNew = new businessOwner(req.body);
    try {
        await businessOwnerNew.save();
        res.status(201).json(businessOwnerNew);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.getBusinessOwner = async (req, res) => {
    try {
        const businessOwnerGet = await businessOwner.findById(req.params.id);
        if (!businessOwnerGet) return res.status(404).json({ message: "Business owner not found" });
        res.json(businessOwnerGet);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.updateBusinessOwner = async (req, res) => {
    const businessOwnerUpdate = req.body;
    try {
        const businessOwnerFind = await businessOwner.findByIdAndUpdate(req.params.id, businessOwnerUpdate, { new: true });
        if (!businessOwnerFind) return res.status(404).json({ message: "Business owner not found" });
        res.json(businessOwnerFind);
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};

exports.deleteBusinessOwner = async (req, res) => {
    try {
        const businessOwnerRemove = await businessOwner.findByIdAndRemove(req.params.id);
        if (!businessOwnerRemove) {
            return res.status(404).json({ message: "Business owner not found." });
        }
        res.status(200).json({ message: "Business owner deleted successfully." });
    } catch (err) {
        res.status(500).json({ message: err.message });
    }
};