const coupon = require("../models/Coupon");
const defaultCoupon = require("../models/defaultCoupon");
const block = require("../models/Block");
const blockChain = require("../models/BlockChain");
const mongoose = require("mongoose");

exports.createDefaultCoupon = async (req, res) => {
  // First, remove any existing defaultCoupon
  try {
    await defaultCoupon.deleteMany();
  } catch (err) {
    res.status(500).json({ message: err.message });
  }

  // Then, create the new defaultCoupon
  const defaultCouponNew = new defaultCoupon(req.body);
  try {
    await defaultCouponNew.save();
    res.status(201).json(defaultCouponNew);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateDefaultCoupon = async (req, res) => {
  try {
    const defaultCouponUpdate = await defaultCoupon.findOne();
    if (defaultCouponUpdate == null) {
      return res.status(404).json({ message: "Cannot find default coupon" });
    }
    Object.assign(defaultCouponUpdate, req.body);
    await defaultCouponUpdate.save();

    // Update all default coupons in the coupon collection
    await coupon.updateMany(
      { isDefault: true },
      {
        expireDate: defaultCouponUpdate.expireDate,
        description: defaultCouponUpdate.description,
      }
    );

    res.json(defaultCouponUpdate);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getDefaultCoupon = async (req, res) => {
  try {
    const coupon = await defaultCoupon.findOne();

    if (!coupon) {
      return res.status(404).json({ message: "No default coupon found." });
    }

    return res.status(200).json(coupon);
  } catch (err) {
    return res.status(500).json({ message: err.message });
  }
};

exports.createCoupon = async (req, res) => {
  const couponNew = new coupon(req.body);
  try {
    await couponNew.save();
    res.status(201).json(couponNew);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getCoupon = async (req, res) => {
  try {
    const blockGet = await block.findOne({
      "data.couponId": req.params.couponId,
    });
    if (blockGet) {
      res.json({
        blockId: blockGet._id,
        ...blockGet.data,
      });
    } else {
      res.status(404).send("Coupon not found");
    }
  } catch (error) {
    res.status(500).send("Server error");
  }
};

exports.getNonDefaultCoupons = async (req, res) => {
  try {
    const nonDefaultCoupons = await coupon.find({ isDefault: false });
    res.status(200).json(nonDefaultCoupons);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateCoupon = async (req, res) => {
  try {
    const couponUpdate = await coupon.findById(req.params.id);
    if (couponUpdate == null) {
      return res.status(404).json({ message: "Cannot find coupon" });
    }
    Object.assign(couponUpdate, req.body);
    await couponUpdate.save();
    res.json(couponUpdate);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.deleteCoupon = async (req, res) => {
  try {
    const couponRemove = await coupon.findByIdAndRemove(req.params.id);
    if (couponRemove == null) {
      return res.status(404).json({ message: "Cannot find coupon" });
    }
    res.json({ message: "Deleted coupon" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.redeemCoupon = async (req, res) => {

  try {
    // 1. Locate the block and blockchain using block_id
    const userChain = await blockChain.findOne({
      "chain._id": req.params.id,
    });

    if (!userChain) {
      return res
        .status(404)
        .json({ message: "Cannot find blockchain containing specified block" });
    }

    // Find the coupon within the chain array
    const couponToRedeem = await block.findById(req.params.id);

    // If the coupon does not exist
    if (!couponToRedeem) {
      return res.status(404).json({ message: "Cannot find coupon" });
    }

    // If the coupon has expired
    const now = new Date();
    if (new Date(couponToRedeem.data.expireDate) < now) {
      return res.status(400).json({ message: "Coupon has expired" });
    }

    // If the coupon is already redeemed
    if (couponToRedeem.data.isRedeemed) {
      return res.status(400).json({ message: "Coupon is already redeemed" });
    }

    // Update the isRedeemed value of the couponToRedeem block
    couponToRedeem.data.isRedeemed = true;
    couponToRedeem.markModified("data");
    await couponToRedeem.save(); // Save the updated block

    // Create a new block that logs the redemption action
    const redemptionData = {
      ...couponToRedeem.data,
      action: "Redeemed",
    };
    const redemptionBlock = new block({
      data: redemptionData,
      timestamp: new Date().toISOString(),
      previousHash: userChain.chain[userChain.chain.length - 1].hash,
      index: userChain.chain[userChain.chain.length - 1].index + 1,
    });

    // Explicitly calculate the hash for the redemption block
    redemptionBlock.hash = redemptionBlock.calculateHash();

    // Append the redemption block to the user's blockchain
    userChain.chain.push(redemptionBlock);

    // Check blockchain integrity after adding the block
    if (!userChain.isChainValid()) {
      return res
        .status(400)
        .json({ message: "Blockchain integrity compromised!" });
    }

    // Save the updated blockchain
    await userChain.save();

    // Send success response
    res.json({ message: "Coupon redeemed successfully" });
  } catch (err) {
    // Send error response
    res.status(500).json({ message: err.message });
  }
};
