const { validationResult } = require("express-validator");
const crypto = require("crypto");
const user = require("../models/User");
const subscription = require("../models/Subscription");
const logChain = require("../models/LogChain");
const userEvent = require("../models/Event");
const log = require("../models/Log");
const block = require("../models/Block");
const blockChain = require("../models/BlockChain");
const coupon = require("../models/Coupon");
const defaultCoupon = require("../models/defaultCoupon");
const CouponCounter = require("../models/CouponCounter");

async function generateUniqueInvitationCode(userId) {
  let base64UserId = Buffer.from(userId, 'hex').toString('base64');
  let invitationCode = base64UserId.substring(0, 6);
  
  // Assuming user is the User model and invitationCode is the field name where the codes are stored
  let existingUser = await user.findOne({ invitationCode });
  
  while (existingUser) {
    // If a user with this invitation code exists, generate a new code with a random suffix
    let randomSuffix = crypto.randomBytes(2).toString('hex');
    invitationCode = base64UserId.substring(0, 6) + randomSuffix;
    
    existingUser = await user.findOne({ invitationCode });
  }

  return invitationCode;
}

const createLogChainEvent = async (activityLog, description) => {
  const logChainUpdate = await logChain.findById(activityLog);
  console.log(logChainUpdate);
  const logChainLen = logChainUpdate.chain.length;
  const prevLog = logChainUpdate.chain[logChainLen - 1];

  const event = new userEvent({
    date: new Date(),
    description,
    topic: "Everything",
  });

  await event.save();

  const newLog = new log({
    index: logChainLen,
    timestamp: new Date(),
    data: event._id,
    previousHash: prevLog?.hash,
  });

  logChainUpdate.chain.push(newLog);
  await logChainUpdate.save();

  console.log(logChainUpdate);
};

const createNewBlockchain = async (userId, businessOwner, data = null) => {
  const genesisBlock = new block({
    index: 0,
    timestamp: new Date().toISOString(),
    previousHash: "0",
    data,
  });
  genesisBlock.hash = genesisBlock.calculateHash();

  const blockchainNew = new blockChain({
    userId,
    businessOwner,
    chain: [genesisBlock],
  });

  await blockchainNew.save();
  return blockchainNew;
};

const addCouponToBlockchain = async (userId, couponId, defaultCoupon) => {
  try {
    const oldChain = await blockChain.findOne({ userId });

    const blockNew = new block({
      index: oldChain.chain.length,
      timestamp: new Date().toISOString(),
      previousHash: oldChain.chain[oldChain.chain.length - 1].hash,
      data: {
        couponId,
        expireDate: defaultCoupon.expireDate,
        description: defaultCoupon.description,
        isPushed: true,
        isDefault: true,
        isRedeemed: false,
      },
    });
    await blockNew.save();

    blockNew.data.block_id = blockNew._id;
    await blockNew.save();

    oldChain.chain.push(blockNew);
    await oldChain.save();

    console.log(
      `Block for coupon ${couponId} added to blockchain for user ${userId}`
    );
  } catch (err) {
    console.error(
      `Error appending block to blockchain for user ${userId}:`,
      err
    );
  }
};

const generateCouponId = async () => {
  let counterDoc = await CouponCounter.findOne();
  if (!counterDoc) {
    counterDoc = new CouponCounter();
    await counterDoc.save();
  }

  counterDoc.counter += 1;
  await counterDoc.save();

  return `FLC-${String(counterDoc.counter).padStart(5, "0")}`;
};

exports.withBlockchainSubscribe = async (req, res) => {
  console.log("Parsed request body:", req.body);
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    const {
      userHash,
      endpoint,
      expirationTime,
      keys,
      invitationCode,
      companyName,
      data,
    } = req.body;

    let userNew = await user.findOne({ userHash });
    let existingSubscription = await subscription.findOne({ endpoint });

    if (userNew && existingSubscription) {
      // Case 1: Both userNew and existingSubscription exist
      // Update user's subscription details and save the updated user
      userNew.subscriptionStatus = true;
      if (!userNew.subInfo.includes(existingSubscription._id)) {
        userNew.subInfo.push(existingSubscription._id);
      }
      await userNew.save();

      await createLogChainEvent(
        userNew.activityLog,
        "Subscribed to everything"
      );

      return res.status(201).json({
        user: userNew,
        message: "Subscription updated.",
      });
    } else if (userNew && !existingSubscription) {
      // Case 2: userNew exists but existingSubscription does not exist

      // Create new subscription record
      let sub = new subscription({
        userId: userNew._id,
        endpoint,
        expirationTime,
        keys,
      });
      await sub.save();

      // Update user's subscription details and save the updated user
      userNew.subscriptionStatus = true;
      userNew.subInfo.push(sub._id);
      await userNew.save();

      await createLogChainEvent(
        userNew.activityLog,
        "Subscribed to everything"
      );

      return res.status(201).json({
        user: userNew,
        message: "New subscription created.",
      });
    } else if (!userNew && existingSubscription) {
      // Case 3: userNew does not exist but existingSubscription exists
      // Create a basic activity log for this user
      let activity = new logChain({
        userHash,
        chain: [],
      });
      await activity.save();

      // Create the user with existing subscription details
      userNew = new user({
        userHash,
        subscriptionStatus: true,
        subInfo: [existingSubscription._id],
        activityLog: activity._id,
      });

      // Generating a unique invitation code for the new user
      userNew.invitationCode = await generateUniqueInvitationCode(userNew._id);

      // If there's an invitation code provided, it means this user was referred by someone
      if (invitationCode) {
        const referrer = await user.findOne({ invitationCode });
        if (referrer) {
          userNew.referredBy = invitationCode;
        } else {
          return res.status(400).json({ message: "Invalid invitation code" });
        }
      }

      await userNew.save();

      // Now create the blockchain
      let blockchainNew = await createNewBlockchain(
        userNew._id,
        companyName,
        data
      );

      // Get or create the CouponCounter and add coupon to the blockchain
      const couponId = await generateCouponId();
      let defaultCouponGet = await defaultCoupon.findOne();
      if (defaultCouponGet) {
        await addCouponToBlockchain(userNew._id, couponId, defaultCouponGet);
      }

      // Update user's subscription details and save
      userNew.subscriptionStatus = true;
      userNew.blockChain = blockchainNew._id;
      await userNew.save();

      // Create a log chain event and save
      await createLogChainEvent(
        userNew.activityLog,
        "Subscribed to everything"
      );

      return res.status(201).json({
        user: userNew,
        blockchain: blockchainNew,
        message: "New user created with existing subscription.",
      });
    } else {
      // Case 4: Neither userNew nor existingSubscription exist
      // Create a basic activity log for this user
      let activity = new logChain({
        userHash,
        chain: [],
      });
      await activity.save();

      // Create the user
      userNew = new user({
        userHash,
        subscriptionStatus: true,
        subInfo: [],
        activityLog: activity._id,
      });
      // Generating a unique invitation code for the new user
      userNew.invitationCode = await generateUniqueInvitationCode(userNew._id);

      // If there's an invitation code provided, it means this user was referred by someone
      if (invitationCode) {
        const referrer = await user.findOne({ invitationCode });
        if (referrer) {
          userNew.referredBy = invitationCode;
        } else {
          return res.status(400).json({ message: "Invalid invitation code" });
        }
      }

      await userNew.save();

      // Now create the blockchain
      let blockchainNew = await createNewBlockchain(
        userNew._id,
        companyName,
        data
      );

      // Get or create the CouponCounter and add coupon to the blockchain
      const couponId = await generateCouponId();
      let defaultCouponGet = await defaultCoupon.findOne();
      if (defaultCouponGet) {
        await addCouponToBlockchain(userNew._id, couponId, defaultCouponGet);
      }

      // Create a new subscription record
      let newSubscription = new subscription({
        userId: userNew._id,
        endpoint,
        expirationTime,
        keys,
      });
      await newSubscription.save();

      // Update user's subscription details and save
      userNew.subscriptionStatus = true;
      userNew.subInfo.push(newSubscription._id);
      userNew.blockChain = blockchainNew._id;
      await userNew.save();

      // Create a log chain event and save
      await createLogChainEvent(
        userNew.activityLog,
        "Subscribed to everything"
      );

      return res.status(201).json({
        user: userNew,
        blockchain: blockchainNew,
        message: "New user and new subscription created.",
      });
    }
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getDefaultCoupon = async (req, res) => {
  try {
    let userFound = await user
      .findOne({ userHash: req.body.userHash })
      .populate("blockChain");
    if (!userFound || !userFound.blockChain || !userFound.blockChain.chain) {
      return res
        .status(404)
        .json({ message: "Cannot find user or blockchain" });
    }

    // Look for the block where isDefault is true
    let defaultCouponBlock = userFound.blockChain.chain.find(
      (block) => block.data && block.data.isDefault
    );

    // If no default coupon found
    if (!defaultCouponBlock || !defaultCouponBlock.data) {
      return res.status(404).json({ message: "No default coupon found" });
    }

    // Return the required details
    res.json({
      couponId: defaultCouponBlock.data.couponId,
      description: defaultCouponBlock.data.description,
      expireDate: defaultCouponBlock.data.expireDate,
    });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getCoupons = async (req, res) => {
  try {
    const userHash = req.body.userHash;

    // 1. Find the user by userHash
    const userGet = await user.findOne({ userHash: userHash });

    if (!userGet) {
      return res.status(404).json({ message: "User not found" });
    }

    // 2. Get the user's blockchain
    const userChain = await blockChain.findById(userGet.blockChain);

    if (!userChain) {
      return res
        .status(404)
        .json({ message: "Blockchain not found for this user" });
    }

    // 3. Extract the user's coupons
    const allCoupons = userChain.chain.slice(1); // Omitting the genesis block
    const couponMap = {};

    // Iterate in reverse to ensure the latest state of each coupon is captured
    for (let i = allCoupons.length - 1; i >= 0; i--) {
      const couponData = allCoupons[i].data;

      // Check if the coupon is unique (by its ID) and capture its latest state
      if (
        couponData &&
        couponData.couponId &&
        !couponMap[couponData.couponId]
      ) {
        couponMap[couponData.couponId] = couponData;
      }
    }

    // Return the latest state of each coupon as an array
    const uniqueCoupons = Object.values(couponMap);

    res.json(uniqueCoupons);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getUserById = async (req, res) => {
  try {
    const userGet = await user.findById(req.params.id);
    if (userGet == null) {
      return res.status(404).json({ message: "Cannot find user" });
    }
    res.json(userGet);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getUserInfo = async (req, res) => {
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(400).json({ errors: errors.array() });
  }
  try {
    const { userHash, endpoint, keys } = req.body;

    // Check if user with this userHash exists
    const userGet = await user
      .findOne({ userHash: userHash })
      .populate("subInfo");
    if (!userGet) {
      return res.status(200).json({ message: "User not found." });
    }

    // Check if subscription with this endpoint and keys exists
    const subscriptionGet = await subscription.findOne({
      endpoint: endpoint,
      "keys.p256dh": keys.p256dh,
      "keys.auth": keys.auth,
    });

    if (!subscriptionGet) {
      return res.status(200).json({ userGet });
    }

    // Check if one of the user's subInfo matches the found subscription
    const matchingSubscription = userGet.subInfo.some(
      (sub) => sub._id.toString() === subscriptionGet._id.toString()
    );

    if (!matchingSubscription) {
      return res.status(200).json({
        message: "User subscription does not match. Unsubscribe in this device",
        userGet,
      });
    }

    res.json(userGet);
  } catch (err) {
    console.log(err);
    res.status(500).json({ message: err.message });
  }
};

exports.getUserByHash = async (req, res) => {
  try {
    const userGet = await user.findOne({ userHash: req.params.hash });
    if (userGet == null) {
      return res.status(404).json({ message: "Cannot find user" });
    }
    res.json(userGet);
  } catch (err) {
    console.error(err); // Log the error
    res.status(500).json({ message: err.message });
  }
};

exports.subscribeUser = async (req, res) => {
  const isValidSaveRequest = (req, res) => {
    if (!req.body || !req.body.endpoint) {
      res.status(400);
      res.setHeader("Content-Type", "application/json");
      res.send(
        JSON.stringify({
          error: {
            id: "no-endpoint",
            message: "Subscription must have an endpoint.",
          },
        })
      );
      return false;
    }
    return true;
  };

  if (!isValidSaveRequest(req, res)) {
    return;
  }

  try {
    // Find the user by id
    const userUpdate = await user.findById(req.params.id);

    // If user does not exist, send an error
    if (!userUpdate) {
      res.status(404);
      res.setHeader("Content-Type", "application/json");
      res.send(
        JSON.stringify({
          error: {
            id: "no-user",
            message: "User does not exist.",
          },
        })
      );
      return;
    }

    // Create new subscription record
    let sub = new subscription({
      userId: userUpdate._id,
      endpoint: req.body.endpoint,
      expirationTime: req.body.expirationTime,
      keys: req.body.keys,
    });
    // Save it
    await sub.save();

    // Update user's subscription details
    userUpdate.subscriptionStatus = true;
    userUpdate.subInfo = sub._id;

    // Save the updated user
    await userUpdate.save();

    // Get the user's LogChain
    const logChainUpdate = await logChain.findById(userUpdate.activityLog);
    console.log(logChainUpdate);
    const logChainLen = logChainUpdate.chain.length;
    const prevLog = logChainUpdate.chain[logChainLen - 1];

    // Create the event
    const e = new userEvent({
      date: new Date(),
      description: "Subscribed to everything",
      topic: "Everything",
    });

    e.save();

    // We don't need to save individual logs, just the chain
    const newLog = new log({
      index: logChainLen,
      timestamp: new Date(),
      data: e._id,
      previousHash: prevLog?.hash,
    });

    logChainUpdate.chain.push(newLog);
    logChainUpdate.save();

    console.log(logChainUpdate);

    res.setHeader("Content-Type", "application/json");
    res.send(JSON.stringify({ data: { success: true } }));
  } catch (err) {
    console.log(err);
    res.status(500);
    res.setHeader("Content-Type", "application/json");
    res.send(
      JSON.stringify({
        error: {
          id: "unable-to-update-subscription",
          message: "An error occurred while updating the subscription.",
        },
      })
    );
  }
};

exports.unsubscribeUser = async (req, res) => {
  try {
    const { userHash, endpoint } = req.body;

    // Find the user by hash
    const userUpdate = await user.findOne({ userHash: userHash });

    // If user does not exist, send an error
    if (!userUpdate) {
      res.status(404).json({
        error: {
          id: "no-user",
          message: "User does not exist.",
        },
      });
      return;
    }

    // Find the specific subscription to be removed using endpoint and userId
    const subscriptionToRemove = await subscription.findOne({
      endpoint: endpoint,
      userId: userUpdate._id,
    });

    if (!subscriptionToRemove) {
      res.status(404).json({
        error: {
          id: "no-subscription",
          message: "No subscription found for this endpoint.",
        },
      });
      return;
    }

    // Delete the identified subscription
    await subscription.findByIdAndRemove(subscriptionToRemove._id).exec();

    // Remove the subscription id from the user's subInfo
    const index = userUpdate.subInfo.indexOf(subscriptionToRemove._id);
    if (index > -1) {
      userUpdate.subInfo.splice(index, 1);
    }

    // Update the user's subscriptionStatus to false if no more subscriptions are present
    if (userUpdate.subInfo.length === 0) {
      userUpdate.subscriptionStatus = false;
    }

    // Save the updated user
    await userUpdate.save();

    // Get the user's LogChain
    const logChainUpdate = await logChain.findById(userUpdate.activityLog);
    const logChainLen = logChainUpdate.chain.length;
    const prevLog = logChainUpdate.chain[logChainLen - 1];

    // Create the event
    const e = new userEvent({
      date: new Date(),
      description: "Unsubscribed from a device",
      topic: "Unsubscription",
    });

    await e.save();

    // Create and append the new log to the LogChain
    const newLog = new log({
      index: logChainLen,
      timestamp: new Date(),
      data: e._id,
      previousHash: prevLog?.hash,
    });

    logChainUpdate.chain.push(newLog);
    await logChainUpdate.save();

    // Send success response
    res.json({ data: { success: true } });
  } catch (err) {
    console.log(err);
    res.status(500).json({
      error: {
        id: "unable-to-update-subscription",
        message: "An error occurred while updating the subscription.",
      },
    });
  }
};

exports.deleteUser = async (req, res) => {
  try {
    const userRemove = await user.findByIdAndRemove(req.params.id);
    if (userRemove == null) {
      return res.status(404).json({ message: "Cannot find user" });
    }
    res.json({ message: "Deleted user" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateSubscription = async (req, res) => {
  try {
    const { old_endpoint, new_endpoint, new_p256dh, new_auth } = req.body;

    if (!old_endpoint || !new_endpoint || !new_p256dh || !new_auth) {
      return res.status(400).json({ error: 'Incomplete subscription data' });
    }

    // Find the old subscription using the old_endpoint
    let oldSubscription = await subscription.findOne({ endpoint: old_endpoint });

    if (!oldSubscription) {
      return res.status(404).json({ error: 'Old subscription not found' });
    }

    // Update the subscription details
    oldSubscription.endpoint = new_endpoint;
    oldSubscription.keys = {
      p256dh: new_p256dh,
      auth: new_auth,
    };

    // Save the updated subscription
    await oldSubscription.save();

    res.status(200).json({ message: 'Subscription updated successfully' });
  } catch (error) {
    res.status(500).json({ error: 'Server error', details: error.message });
  }
};