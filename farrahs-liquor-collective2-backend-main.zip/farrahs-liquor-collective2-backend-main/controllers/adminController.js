const crypto = require("crypto");
const user = require("../models/User");
const Admin = require("../models/Admin");
const jwtUtils = require("../utils/jwtUtils");

function generateUserHash(data) {
  return crypto.createHash("sha256").update(data).digest("hex");
}

exports.getUserInfoAdmin = async (req, res) => {
  try {
    // Assume user's personal info is sent as a JSON string in the 'data' field
    const hash = generateUserHash(req.body.data);

    const userTry = await user.findOne({ userHash: hash });

    if (!userTry) {
      return res.status(404).json({ error: "User not found" });
    }

    res.json(userTry);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};

exports.login = async (req, res) => {
  const { username, password } = req.body;

  try {
    const admin = await Admin.findOne({ username });
    if (!admin) {
      console.log("Admin not found for username:", username); // Log the issue
      return res.status(400).json({ message: "Invalid username or password." });
    }

    const isMatch = await admin.comparePassword(password);
    if (!isMatch) {
      return res.status(400).json({ message: "Invalid username or password." });
    }

    const token = jwtUtils.issueToken(admin._id);
    res.json({ token });
  } catch (error) {
    console.error(error);
    res.status(500).json({ message: "Server error." });
  }
};
