const mongoose = require('mongoose');
const retry = require('async-retry');

async function connectWithRetry() {
    await retry(async bail => {
        try {
            await mongoose.connect(process.env.DB_URL, {
                useNewUrlParser: true,
                useUnifiedTopology: true
            });
            console.log('Successfully connected to the database!');
        } catch (err) {
            console.error('Failed to connect to MongoDB on startup - retrying in 5 sec', err);
            bail(err); // If you want to retry
        }
    }, {
        retries: 5,
        minTimeout: 5000, // 5 seconds
    });
}

connectWithRetry();

module.exports = mongoose;
