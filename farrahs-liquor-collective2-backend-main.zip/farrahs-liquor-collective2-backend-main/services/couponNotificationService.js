const express = require('express');
const router = express.Router();
const webpush = require('web-push');
const schedule = require('node-schedule');
const subscription = require('../models/Subscription');
const coupon = require('../models/Coupon');
const { appendBlockToBlockchain } = require('../utils/helpers');

// NOTIFICATION ENDPOINTS
// VAPID keys should have been generated and used here
const vapidKeys = {
    publicKey: process.env.PUBLICVAPIDKEY,
    privateKey: process.env.PRIVATEVAPIDKEY,
};

const GCM_API_KEY = "BOcoT56ph6yfxP_qjRcaNGtW5MbXpgOkYsXE3NI3lap_qdneF2_WzQlWR2YjHX5Ublq4hGaUIRb06tNhdR8-V1w"; // Replace with your Firebase Server Key
webpush.setGCMAPIKey(GCM_API_KEY);

webpush.setVapidDetails(
    'mailto:example@yourdomain.org',
    vapidKeys.publicKey,
    vapidKeys.privateKey
);

router.post('/pushMes', (req, res) => {
    const subscription = req.body.subscription;
    const payload = JSON.stringify({ title: req.body.title });

    webpush.sendNotification(subscription, payload)
        .then(result => res.status(200).json(result))
        .catch(err => {
            console.error(err);
            res.sendStatus(500);
        });
});

// Scheduling job to run every minute.
const job = schedule.scheduleJob('* * * * *', function () {
    console.log('Checking for coupons to push...');

    // Get the current minute
    let currentMinute = new Date();
    currentMinute.setSeconds(0);
    currentMinute.setMilliseconds(0);

    // Get the next minute
    let nextMinute = new Date(currentMinute.getTime() + 60000);

    // Fetch all coupons that have a scheduleTime within the current minute and isPushed is false
    coupon.find({ scheduleTime: { $gte: currentMinute, $lt: nextMinute }, isPushed: false })
        .then(coupons => {
            // Loop through all the coupons and push notification
            coupons.forEach(coupon => {
                // Update the isPushed flag in the database
                coupon.isPushed = true;
                coupon.save()
                    .then(() => {
                        console.log('Coupon status updated');

                        // Fetch all user subscriptions
                        subscription.find()
                            .then(subscriptions => {
                                subscriptions.forEach(subscription => {
                                    const payload = JSON.stringify({ title: coupon.description });

                                    if (subscription.endpoint.startsWith('https://android.googleapis.com/gcm/send')) {
                                        // It's GCM
                                        webpush.sendNotification(subscription, payload, {
                                            gcmAPIKey: GCM_API_KEY
                                        })
                                            .then(result => {
                                                console.log('Notification sent:', result);
                                                appendBlockToBlockchain(coupon._id, subscription.userId);
                                            })
                                            .catch(err => {
                                                console.error('Error sending notification:', err);
                                            });
                                    } else {
                                        // It's VAPID
                                        webpush.sendNotification(subscription, payload)
                                            .then(result => {
                                                console.log('Notification sent:', result);
                                                appendBlockToBlockchain(coupon._id, subscription.userId);
                                            })
                                            .catch(err => {
                                                console.error('Error sending notification:', err);
                                            });
                                    }
                                });
                            })
                            .catch(err => console.error('Error fetching subscriptions:', err));
                    })
                    .catch(err => console.error('Error updating coupon:', err));
            });
        })
        .catch(err => console.error('Error fetching coupons:', err));
});


module.exports = router;
