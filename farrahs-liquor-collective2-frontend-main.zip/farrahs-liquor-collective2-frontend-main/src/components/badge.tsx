import utilStyles from "src/app/styles/utils.module.scss";

export default function Badge() {
  return (
    <div className={utilStyles.badge}>
      {/* Securely
      <div>Sign. 01</div> */}
    </div>
  );
}
